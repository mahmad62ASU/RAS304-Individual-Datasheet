PITCH AXIS MOTOR CONTROL - REVISION 1.2
Muhammad Ayaan Ahmad | Team 103 | 16 November 2026

Open Pitch_Axis_MAA.kicad_pro in KiCad 10. Symbols and footprints are included locally.

PROFESSOR COMMENTS
1. JP7 is a two-pin VOFF-to-ground jumper, fitted for external 5 V operation through JP1/VTG.
2. UART RX and TX now share J4: pin 1 RX, pin 2 TX, pin 8 ground; pins 3-7 unused. J5 is removed. J3 is AUX I/O. Published team diagrams were reviewed, but Connor's main-board TX/RX directions are not documented. Confirm complementary TX/RX assignments before wiring the ribbon cable.
3. All 15 capacitors are non-polar. C1/C7 use the specified Nichicon bipolar parts; C4 and the remaining capacitors are ceramic. Values, ratings and footprints are in the BOM.

PCB
100 x 100 mm; two copper layers, 0.0175 mm each (~0.5 oz); 1.5 mm total thickness.
Manual routing; 40 mil power/ground tracks and 15 mil signal tracks.
Ground copper on front, +5 V copper on back. Four mounting holes and test points.
The saved GUI DRC, with zone refill and schematic comparison enabled, reports 0 violations, 0 unconnected items and 0 schematic-parity findings. ERC reports 0 errors and 0 warnings. The reports explicitly list configured ignored checks; no per-item exclusions were used to turn findings into passes.

FILES
Schematic.pdf / Schematic.png: compact A3 schematic.
PCB-Front.pdf / PCB-Back.pdf: KiCad 1:1 artwork; print at 100%, not fit-to-page.
PCB-Front.png / PCB-Back.png: board previews.
PCB-3D.png / PCB-Top-Assembly.png / PCB-Bottom-Assembly.png: KiCad assembly renders.
Presentation-Update.txt: silkscreen and 3D-model notes; electrical geometry is unchanged.
Ahmad_MuhammadAyaan_DRC.pdf: actual DRC screenshot alongside the board export.
DRC-Report.rpt and ERC-Report.txt: actual validation reports.
Bill-of-Materials.csv / Parts-and-Reasons.html: current parts and their purpose.
Gerbers/: seven Gerber layers and two Excellon drill files (inch units).
Trace-Width-Check.txt: 1 A / 0.5 oz external trace calculation.
Export-Verification.json: hashes linking exports to the saved PCB.

OUTSTANDING BEFORE MANUFACTURE / SUBMISSION
- JLCDFM analysis and its genuine screenshot have not been completed.
- Physically place the real components on a 1:1 printout; this cannot be verified from files alone.
- U6/U7 are the specified Nexperia TSSOP-8 parts, 0.65 mm pitch and 0.40 mm pad width. These are below the Peralta package guidance (0.80 mm pitch / 0.51 mm pad), which directs smaller packages to professor/Lab Manager review. Their manufacturer landing patterns have not been enlarged to conceal this issue.
- Confirm the main-controller UART pin directions and AUX I/O harness with the team.
- Updated website files are prepared locally. The website has not been published and Canvas has not been submitted.

Assignment: https://ras-embedded-systems.pages.dev/304/individual-assignments/pcb-design/
Peralta specs: https://labs.engineering.asu.edu/peraltastudios/pcb-mill-specs
