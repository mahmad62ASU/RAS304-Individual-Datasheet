PITCH AXIS MAA - SCHEMATIC DESIGN
Muhammad Ayaan Ahmad | RAS304 Team 103 | 21 October 2026

Open Pitch_Axis_MAA.kicad_pro in KiCad 10 (created with 10.0.6).
The A1 schematic is intentionally vector-based; zoom or print at original size.
Project-local symbols and footprint copies are included in sym-lib-table and fp-lib-table.
No PCB layout has been created; that is a later assignment.

Design basis: Team 103 Product Requirements assigns Ayaan the Node 2 pitch-axis motor board. The earlier individual optical-sensor component proposal is inconsistent with this allocation and is not the basis of this schematic. Team Block Diagram remains template content.

JP1: target 5V power isolation; fit for operation. VOFF hard grounded; VBUS never connected to external rail.
JP2/JP3: pitch direction and PWM input isolation.
JP4: common fault-bus isolation; fit for integration after standalone checks.
JP5: motor branch isolation; remove for logic-only checks.
JP6: local fault pull-up; fit standalone. Exactly one pull-up across interconnected boards.

Motor envelope is provisional: a 9-12V rated brushed DC gearmotor, <=0.35A continuous; approximately 0.486A DC return-current latch threshold and 0.64A nominal internal winding-current chopping. Motor torque, startup current, gear ratio, braking and limits are not specified in the team's published material and must be validated. Select a regulated 9-12V >=2A center-positive supply.

U1 is L7805ACV (the A grade, not the wider-tolerance L7805CV); fit a <=25C/W heatsink.
F1: 1A fast 5x20 fuse; F2: 250mA fast 5x20 fuse. Each holder uses two Littelfuse 100 series clips. Validate fuse curves against inrush, conductor ratings and maximum fault current.

U3 is a bare DRV8871DDAR soldered to the PCB, not a module. GND, PGND and exposed pad return together above R3. Their isolated copper island must not be shorted to circuit common. Provide thermal copper and vias per TI; Kelvin-route R3.

Firmware must configure RD1 for Schmitt-trigger digital input, RA0 for ADC, RC2/RC3 as PWM, RC7/RC6 through PPS for UART. Start both PWM pins low. Do not arm automatically after power restoration or fault. Check FAULT_N and require an explicit button event before an ARM_PULSE rising edge. The MCU must manage direction changes and dead time.

J3 follows the published team mapping: 1 pitch direction, 2 pitch PWM, 3 roll direction, 4 roll PWM, 5 active-low shared fault, 6 roll analog, 7 load analog, 8 common. Pins 3/4/6/7 connect only to test pads. J4 upstream RX and J5 downstream TX use separate ground-referenced headers because the published IDC map has no free UART pair. Team UART topology still needs integration agreement.

No circuit has been built or bench-tested for this assignment. ERC and netlist checks are recorded separately. Review all actual purchased component packages and footprints before PCB fabrication.
