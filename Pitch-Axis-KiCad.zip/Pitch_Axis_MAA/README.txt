PITCH AXIS MOTOR CONTROL | TEAM 103 NODE 2 | REVISION 1.1
Muhammad Ayaan Ahmad | RAS 304 | 12 November 2026

Open Pitch_Axis_MAA.kicad_pro in KiCad 10. The A1 schematic PDF can be
zoomed for component values and pin labels. Project symbol and footprint
libraries are included. See Bill-of-Materials.csv for schematic positions
and the revised purchase request for ordered parts and quantities.

INSTRUCTOR COMMENTS

1. U1 is the kit's Taejin LM7805T in TO-220. Pin 1 is input, pin 2 is
   ground and pin 3 is output. C2 and C3 are 330 nF and 100 nF respectively.
   R1 provides a nominal 5 mA preload. Measure the loaded rail and
   regulator temperature. J1 is the kit PJ-102AH center-positive jack.
2. Section 08 shows SW1, the B3F-1000 debug/arm-request pushbutton. R16,
   R17 and C15 form its debounce circuit. Pressing it pulls BUTTON_N low
   at the PIC's RD1 on module pad 21. Firmware decides whether to arm.
3. J3, J4 and J5 are keyed 2×4 Adam Tech BHR-08-VUA headers. J3 retains
   the team signal map. The proposed separate J4 upstream and J5
   downstream cables use pin 1 for UART and pin 8 for common, with
   pins 2–7 unused. Use labeled FCS-08-SG mating sockets, keep the pin-1
   stripe aligned, and agree on the cable map and voltage with the team.
4. R24 biases spare U4B from VTRIP and its feedback keeps it a follower.
   R25 biases spare U5B's + input to ground and R26 biases its - input
   to VTRIP. The unused U5B output has an explicit no-connect marker.
5. R6 (1 kΩ) and C8 (100 nF) create a 1.59 kHz low-pass filter at
   CURRENT_ADC before RA0 (pad 43). Confirm ADC sampling against PWM on
   the bench.
6. U4A amplifies the 0.10 Ω shunt voltage by 21 V/V using R4 and R5.
   A DC 0.35 A return current gives about 0.735 V at the ADC. The nominal
   comparator trip is about 0.486 A at DC. The shunt measures the driver
   supply return current. Current circulating inside the H-bridge can
   bypass this measurement. DRV8871 supplies internal current regulation.

BOARD INTERFACES

J3 (team bus), pin 1 pitch DIR, 2 pitch PWM, 3 roll DIR monitor,
4 roll PWM monitor, 5 shared active-low fault, 6 roll analog monitor,
7 load analog monitor, 8 common. No power rail on J3, J4 or J5.
J4 pin 1 receives upstream TX at U2 RC7 (pad 19). J5 pin 1 sends U2
RC6 (pad 13) to downstream RX. Each is 5 V logic. Set PPS in firmware.
J6 connects the isolated pair of motor wires to the DRV8871 H-bridge.
Use OSTTC022162 with the 5.08 mm footprint and verify the actual fit.

BUILD NOTES

Use a current-limited 9–12 V DC bench source with a center-positive
plug. Verify a lab motor's voltage, running current and stall behavior.
The design envelope assumes a 9–12 V brushed DC gearmotor drawing at
most 0.35 A continuously. Start with JP5 open for logic-only checks.
Use the specified fuses and holders from lab stock. F1 is 1 A fast,
and F2 is 250 mA fast, each in a 5×20 mm holder. Verify fuse curves
against the actual motor, inrush and conductor ratings.

Keep the DRV8871 ground and exposed-pad island above R3. Kelvin-route
the shunt and follow TI's thermal layout guidance. R3 is Yageo
PE2512FKE7W0R1Z. D1 is TSC 1N5822, D2 is Littelfuse SMBJ15A, D3 is
onsemi 1N5819RLG and Q1 is onsemi KSP2222ABU (E-B-C, pins 1–3).
U6 and U7 use the Nexperia TSSOP-8 parts and SOT505-2 solder lands.

JP6 installs the local FAULT_N pull-up for standalone testing. Use one
pull-up across the connected team bus. The latched fault drives both
motor inputs low. Verify it stays latched after the fault clears and
requires a fresh deliberate arm event. These are schematic checks.
Bench tests, team harness validation and PCB layout remain pending.

SOURCES
Kit BOM: https://ras-embedded-systems.pages.dev/304/BOM-Consolidated/
LM7805T datasheet: https://htckorea.co.kr/Datasheet/Voltage%20Regulator/LM78xx.pdf
SOT505-2 land pattern: https://assets.nexperia.com/documents/package-information/SOT505-2.pdf
TI DRV8871: https://www.ti.com/lit/ds/symlink/drv8871.pdf
